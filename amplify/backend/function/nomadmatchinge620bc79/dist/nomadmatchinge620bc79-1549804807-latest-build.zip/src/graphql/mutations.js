// eslint-disable
// this is an auto generated file. This will be overwritten

export const createUserProfile = `mutation CreateUserProfile($input: CreateUserProfileInput!) {
  createUserProfile(input: $input) {
    identityId
    email
    profileImageUrl
    name
    screenName
  }
}
`;
export const updateUserProfile = `mutation UpdateUserProfile($input: UpdateUserProfileInput!) {
  updateUserProfile(input: $input) {
    identityId
    email
    profileImageUrl
    name
    screenName
  }
}
`;
export const deleteUserProfile = `mutation DeleteUserProfile($input: DeleteUserProfileInput!) {
  deleteUserProfile(input: $input) {
    identityId
    email
    profileImageUrl
    name
    screenName
  }
}
`;
