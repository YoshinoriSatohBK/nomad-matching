// eslint-disable
// this is an auto generated file. This will be overwritten

export const onCreateUserProfile = `subscription OnCreateUserProfile {
  onCreateUserProfile {
    identityId
    email
    profileImageUrl
    name
    screenName
  }
}
`;
export const onUpdateUserProfile = `subscription OnUpdateUserProfile {
  onUpdateUserProfile {
    identityId
    email
    profileImageUrl
    name
    screenName
  }
}
`;
export const onDeleteUserProfile = `subscription OnDeleteUserProfile {
  onDeleteUserProfile {
    identityId
    email
    profileImageUrl
    name
    screenName
  }
}
`;
